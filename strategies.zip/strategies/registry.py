"""Live strategy registry.

Only explicitly approved live strategies are loaded here.
Research strategies are intentionally excluded so optional dependencies cannot
affect production startup.
"""

from __future__ import annotations

import importlib


LIVE_STRATEGY_MODULE_NAMES = [
    "strategy_a",
    "strategy_b",
    "strategy_d",
    "strategy_h",
    "strategy_tf1",
    "strategy_ema1",
    "strategy_ema2",
    "strategy_ema3",
    "strategy_sma1",
    "strategy_vwema1",
]


FAILED_STRATEGIES = []


def _load_live_strategies():
    loaded = []

    for name in LIVE_STRATEGY_MODULE_NAMES:
        try:
            module = importlib.import_module(f".{name}", __package__)
            loaded.append(module)
        except Exception as exc:
            FAILED_STRATEGIES.append(
                {
                    "strategy": name,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )

    return loaded


ENABLED_STRATEGIES = _load_live_strategies()


for failed in FAILED_STRATEGIES:
    print(
        "STRATEGY_LOAD_WARNING",
        failed["strategy"],
        failed["error"],
        flush=True,
    )


def evaluate_all(context):
    results = []

    for strategy in ENABLED_STRATEGIES:
        evaluate = getattr(strategy, "evaluate", None)

        if evaluate is None:
            continue

        results.extend(evaluate(context))

    return results
