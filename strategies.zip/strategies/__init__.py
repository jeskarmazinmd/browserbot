"""Modular trading-strategy implementations."""
